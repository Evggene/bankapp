package org.bea;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class TestMain {
}
