package org.bea.config;

import com.fasterxml.jackson.core.type.TypeReference;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.bea.domain.CurrencyRate;
import org.springframework.boot.autoconfigure.kafka.KafkaProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;
import org.springframework.kafka.listener.ContainerProperties;
import org.springframework.kafka.support.serializer.JsonDeserializer;

import java.util.List;
import java.util.Map;

@Configuration
@EnableKafka
public class KafkaConfig {

    @Bean
    public ConsumerFactory<String, List<CurrencyRate>> consumerFactory(KafkaProperties properties) {
        Map<String, Object> cfg = properties.buildConsumerProperties();
        cfg.put(ConsumerConfig.ENABLE_AUTO_COMMIT_CONFIG, false);
        JsonDeserializer<List<CurrencyRate>> json = new JsonDeserializer<>(new TypeReference<List<CurrencyRate>>() {});
        return new DefaultKafkaConsumerFactory<>(cfg, new StringDeserializer(), json);
    }

    // оставляем стандартное имя бина, чтобы @KafkaListener без containerFactory подхватил его
    @Bean
    public ConcurrentKafkaListenerContainerFactory<String, List<CurrencyRate>> kafkaListenerContainerFactory(
            ConsumerFactory<String, List<CurrencyRate>> consumerFactory) {
        var factory = new ConcurrentKafkaListenerContainerFactory<String, List<CurrencyRate>>();
        factory.setConsumerFactory(consumerFactory);
        factory.getContainerProperties().setAckMode(ContainerProperties.AckMode.MANUAL_IMMEDIATE);
        factory.getContainerProperties().setSyncCommits(true);
        factory.getContainerProperties().setPollTimeout(3000);
        return factory;
    }
}
