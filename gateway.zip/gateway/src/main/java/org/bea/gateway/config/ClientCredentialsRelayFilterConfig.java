package org.bea.gateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpStatus;
import org.springframework.security.authentication.AnonymousAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.core.OAuth2AuthorizationException;
import org.springframework.web.servlet.function.*;

import java.util.List;
import java.util.Optional;

@Configuration
public class ClientCredentialsRelayFilterConfig {

    @Bean
    HandlerFilterFunction<ServerResponse, ServerResponse> clientCredentialsRelay(
            OAuth2AuthorizedClientManager manager) {

        return (request, next) -> {
            // Нужен principal для менеджера (анонимный ок)
            Authentication principal = Optional.ofNullable(SecurityContextHolder.getContext().getAuthentication())
                    .orElseGet(() -> new AnonymousAuthenticationToken(
                            "gateway", "gateway", List.of(new SimpleGrantedAuthority("ROLE_ANONYMOUS"))));

            var authorize = OAuth2AuthorizeRequest
                    .withClientRegistrationId("gateway-client") // registrationId из application.yml
                    .principal(principal)
                    .build();

            try {
                var client = manager.authorize(authorize);
                if (client == null || client.getAccessToken() == null) {
                    return ServerResponse.status(HttpStatus.UNAUTHORIZED).body("Unable to obtain client_credentials token");
                }

                var token = client.getAccessToken().getTokenValue();

                // Добавляем Authorization в исходящий запрос к целевому сервису
                var mutated = ServerRequest.from(request)
                        .headers(h -> h.setBearerAuth(token))
                        .build();

                return next.handle(mutated);

            } catch (OAuth2AuthorizationException ex) {
                return ServerResponse.status(HttpStatus.UNAUTHORIZED).body("Keycloak auth error: " + ex.getError().getErrorCode());
            }
        };
    }
}
