package org.bea.gateway.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.function.RouterFunction;
import org.springframework.web.servlet.function.RouterFunctions;
import org.springframework.web.servlet.function.RequestPredicates;
import org.springframework.web.servlet.function.ServerResponse;
import org.springframework.cloud.gateway.server.mvc.handler.HandlerFunctions;
import org.springframework.cloud.gateway.server.mvc.filter.FilterFunctions;
import org.springframework.web.servlet.function.HandlerFilterFunction;

@Configuration
public class ExchangeGeneratorRouteConfig {

    @Bean
    RouterFunction<ServerResponse> exchangeGeneratorRoutes(
            HandlerFilterFunction<ServerResponse, ServerResponse> clientCredentialsRelay) {

        return RouterFunctions.route(
                        RequestPredicates.path("/exchange-generator/**"),
                        HandlerFunctions.http("lb://exchange-generator")
                )
                .filter(FilterFunctions.rewritePath("/exchange-generator/(?<segment>.*)", "/${segment}"))
                .filter(clientCredentialsRelay);
    }
}
